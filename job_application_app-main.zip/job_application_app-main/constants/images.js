import profile from "../assets/images/atyush.jpg";

export default {
  profile,
};
